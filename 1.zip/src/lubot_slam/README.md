# lubot_slam
使用Arduino作为BaseController配合ROS机器人操作系统，构建具备SLAM能力的 luBot 自主导航机器人，也许还有点弱智能（机器视觉与深度学习）。
